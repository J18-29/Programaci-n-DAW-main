package Modelo;

public interface Identificacion {
    String identificar();
}
