import Controlador.ClaseController;

public class Main {
    public static void main(String[] args) {
        ClaseController app = new ClaseController();
        app.iniciar();
    }
}
