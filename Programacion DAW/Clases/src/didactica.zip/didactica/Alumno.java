package didactica;

public class Alumno {
    public String Nombre;
    String direccion;

    public Alumno(){

    }

    public void setNombre(String nombre){

    }
    public String getNombre(){
        return this.Nombre;
    }
}
