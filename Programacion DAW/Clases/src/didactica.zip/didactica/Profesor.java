package didactica;

public class Profesor {
    String nombre;
    String materia;
    Alumno a;

    public Profesor(){
        a.getNombre();
    }
}
