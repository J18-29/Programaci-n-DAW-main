package Clases.BlackJack;

public class Crupier extends Jugadores {
     // Constructor del crupier
    public Crupier() {
        // Llamamos al constructor de la clase Jugadores con el nombre "Crupier"
        super("Crupier");
    }
}
