package Interfaces;

public interface Volador {
    void volar();
}
