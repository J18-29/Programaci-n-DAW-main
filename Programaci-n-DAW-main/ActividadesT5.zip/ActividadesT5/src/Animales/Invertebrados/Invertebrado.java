package Animales.Invertebrados;



import Animales.Animal;

public abstract class Invertebrado extends Animal {

    public Invertebrado(String nombre) {
        super(nombre);
    }
}
