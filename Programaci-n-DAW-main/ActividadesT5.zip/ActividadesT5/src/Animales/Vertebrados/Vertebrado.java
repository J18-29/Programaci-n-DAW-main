package Animales.Vertebrados;



import Animales.Animal;

public abstract class Vertebrado extends Animal {

    public Vertebrado(String nombre) {
        super(nombre);
    }
}

