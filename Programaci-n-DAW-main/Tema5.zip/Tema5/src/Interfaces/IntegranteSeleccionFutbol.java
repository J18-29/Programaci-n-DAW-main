package Interfaces;

public interface IntegranteSeleccionFutbol {

    void concentrarse();
    void viajar();
    void entrenar();
    void jugarPartido();
}
