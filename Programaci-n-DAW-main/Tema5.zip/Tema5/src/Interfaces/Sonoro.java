package Interfaces;

public interface Sonoro {
    void emitirSonido();
}
