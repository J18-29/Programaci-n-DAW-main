package Interfaces;

public interface Movible {
    void mover();
}
